Installation instructions
-------------------------
copy brp directory to c:\brp
edit brp-config.bat with notepad, change site name and password as instructed
sequence will run invisible.vbs brp-send-receive.bat to send encrypted data and get coordinates.ini

curl
Upload/download files using http and more
from curl-7.50.3.zip on curl.haxx.se referenced by sourceforge

zip
Classic, very portable zip utility
From zip300xn-x64.zip on ftp.info-zip.org