#!/usr/bin/env perl
#
# implement U Minn, CMRR, BRP file transfer API
# Joe Gillen - Johns Hopkins SOM - 2017/03/09
#  2017/04/25 prclog command to display latest site process log
#  2017/04/25 -k switch / Delete after send checkbox
#  2017/04/25 -p switch and Philips swap mode for Philips NIFTI
#  2017/04/27 philipsInline code

use strict;
use warnings;
use File::Basename;
use Cwd qw/getcwd realpath/;

my $brp;		# SW path, auto set as this script's folder
BEGIN {
  $brp = dirname($0);			# use dir of script
  $brp = $brp ? realpath ($brp) :	# if $0 was just script name
    getcwd();				# use current dir
  $brp =~ s|\\|/|g;			# Windows to Unix
  push @INC, "$brp/lib";		# for Perl modules
}

use IO::Socket::INET;
use IO::Select;
use Module::Load;

#===========================================================================
# configuration
my $site    = "jhu";		# site name
my $zpass   = "edfrtghy";	# zip encryption password
my $npass   = "jhu9ol.,ki8";	# network password
my $retries = 50;		# tries to check status before giving up
my $sleep   = 5;	        # time (sec) to sleep between retries
# key files
my $zipfile = "outbox/upload.zip";
my $control = "outbox/control.ini";
my $coord   = "inbox/coordinates.ini";
# control file data - 1st value used as default for new control file
my $dmodes  = "upload|recalc";	# 2 data modes
my $voxels  = "cbwm|hippo|pcc|pons|vermis|putamen|occ"; # 7 voxel areas
my $smodes  = "siemens|philips"; # 2 swap modes
my $contregex = qr/^dataMode=($dmodes)[\r\n]+voxelArea=(($voxels)(,($voxels))*)[\r\n]+(swapMode=($smodes)[\r\n]+)?/m; # regex to extract values from control
#
my $brpurl  = "https://brp.cmrr.umn.edu/"; # BRP url
my $roidregex = qr/^(MRSERIES_\d+_\d+)/; # Philips roid format
#===========================================================================
my $bpl = basename($0);
my %cmd;
$cmd{create} = "
Usage: $bpl create|delete -s study-name
  create         - create named study.
  delete         - delete named study.

  Many commands allow an optional study-name parameter [-s study-name].
  If not specified, the default study is used. For the voxel processing
  pipeline, only the default study is used.
";
$cmd{delete} = $cmd{create};
$cmd{status} = "
Usage: $bpl status

  Current status is retrieved from the server and printed or displayed
  in the status field of the GUI.
";
$cmd{log} = "
Usage: $bpl log

  Retrieve the log of events from the server and printed or display in the
  message area of the GUI.
";
$cmd{files} = "
Usage: $bpl files

  List of files for the study is retrieved and printed or displayed in the
  message area of the GUI.
";
$cmd{send_control} = "
Usage: $bpl send_control

  The control file is ($control) and ready status is sent to
  the BRP server.
";
$cmd{receive} = "
Usage: $bpl receive

  The coordinate file is retrieved from the server and stored in
  $coord.
";
$cmd{recalc_receive} = qq~
Usage: $bpl recalc_receive [voxel-area] [swap-mode]

  Send control file ($control) and ready status to the BRP server,
  wait for complete then receive the coordinate file ($coord).
   If voxel-area(s) is specified, set the voxelArea in the control file.
   If swap-mode is specified, set swapMode in control file.
   The dataMode in the control file is automatically set to "recalc".
~;
$cmd{send} = qq~
Usage: $bpl send [voxel-area] [swap-mode] [-k] folder-name

  Send data, control file ($control) and ready status to the server.
   If voxel-area(s) is specified, set the voxelArea in the control file.
   If swap-mode is specified, set swapMode in control file.
   The dataMode in the control file is automatically set to "upload".
   The folder-name is the relative or absolute path to the folder containing
     the image data to be sent.
   If -k, keep selected data, otherwise it is deleted.
~;
$cmd{send_receive} = qq~
Usage: $bpl send_receive [voxel-area] [swap-mode] [-k] folder-name

  Send data, control file ($control) and ready status the the server,
  wait for complete then receive coordinate file ($coord).
   If voxel-area(s) is specified, set the voxelArea in the control file.
   If swap-mode is specified, set swapMode in control file.
   The dataMode in the control file is automatically set to "upload".
   The folder-name is the relative or absolute path to the folder containing
     the image data to be sent.
   If -k, keep selected data, otherwise it is deleted.
~;
$cmd{philips_inline} = qq~
Usage: $bpl philips_inline [voxel-area] [swap-mode] [-k] roid

  Extract images for the series roid from the scanner database, convert to
  NIFTI format, send data and control files, set ready, wait for complete,
  receive coordinate file. Generally called only from a Philips Inline
  Processing step connected to an ExamCard.
   If voxel-area(s) is specified, set the voxelArea in the control file.
   If swap-mode is specified, set swapMode in control file.
   The dataMode in the control file is automatically set to "upload".
   roid is the Philips database roid for the series to be extracted.
   If -k, keep NIFTI data, otherwise it is deleted.
~;
$cmd{list} = "
Usage: $bpl list

  Show the list of studies for this site.
";
$cmd{api_help} = "
Usage: $bpl api_help

  Show the API help text.
";
$cmd{show_control} = "
Usage: $bpl show_control

  Show the contents of the control file ($control).
";
$cmd{show_coord} = "
Usage: show_coord

  Show the contents of the coordinates file ($coord).
";
$cmd{prclog} = "
Usage: $bpl prclog

  Show the latest process log.
";
$cmd{set_control} = "
Usage: $bpl set_control [<data-mode>] [<voxel-area>] [<swap-mode>]

  Set the control file ($control) parameters.
  Unspecified parameters are not changed if the file exists,
  otherwise defaulted.
    data mode: one of $dmodes
    voxel area: 1 or more (comma separated) $voxels
    swap mode: one of $smodes
";
$cmd{gui} = "
Usage: $bpl gui [command [arguments...]]
  Open the BRP File Transfer GUI. Optional command will be executed when the
  GUI opens. The command can be any other valid command with arguments.
";
my $i = 0;
$cmd{help} = "
This script implements the BRP server API for transfer of images to the
pipeline for spectroscopy voxel coordinate determination. Valid commands:
  ".join ("", map {my $l=length($_)+2; $i+=$l;
		   if ($i>80) {$i=$l;"\n  ".$_.", "} else {$_.", ";} }
	  sort keys %cmd)."

Use: brp.pl help [command]

  to get information on any command.
";
# text displayed in GUI when Help is activated
my %help =
  (
   enStudy => "Current study name",
   buStatus => "Show status of the BRP
server processor.",
   buSend => "Send image folder to BRP
server for processing. Mode
is set to upload and current
voxel areas are set in control
file.",
   buSendRec => "Send image folder to BRP
server for processing. Mode
is set to upload and current
voxel areas are set in control
file. Wait for complete then
receive coordinates file back.",
   cbDelete => "Delete folder after send.",
   buFiles => "Show list of files currently
stored on BRP server.",
   buLog => "Show the log file on the BRP
server.",
   buPrcLog => "Show the latest process log on
the BRP server.",
   buShowCoord => "Display the coordinates file
saved on the local host.",
   buReceive => "Retrieve the coordinates file
from the BRP server.",
   buRecalcReceive => "Send the control file, with mode
set to recalc and the current
voxel areas. Wait for complete
then retrieve the coordinates file.",
   buSaveControl => "Save current mode and voxel areas
in the control file.",
   buShowControl => "Display the control file.",
   buSendControl => "Send the control file
to BRP server.",
   rbMode1 => "Select upload transfer mode. This
mode ",
   rbMode2 => "Select this transfer mode.",
   rbSMode0 => "Select Siemens swap mode. Use this
for DICOM files.",
   rbSMode1 => "Select Philips swap mode. Use this
for NIFTI files created using dcm2niix from Philips
REC/PAR data.",
   cbVoxel0 => "Select/deselect this voxel area.",
   cbVoxel1 => "Select/deselect this voxel area.",
   cbVoxel2 => "Select/deselect this voxel area.",
   cbVoxel3 => "Select/deselect this voxel area.",
   cbVoxel4 => "Select/deselect this voxel area.",
   buClearMessages => "Clear the message box.",
   txMsg => "Output of any of the GUI commands.",
   enStatus => "Last status from
the BRP server.",
  );
#===========================================================================
my (@cmdout, %ui, $dlgHlp, $std, $cmd, $server, $select, $brpport, $repId);
my $gui = 0; my $help = 0;
my @voxels = split /\|/, $voxels;
my $port = 13332;

$SIG{__DIE__} = sub {			# trap die
  &msg ("\n", $_[0]);			# message
  $gui and return;			# if gui just return
  $_[0] =~ /^Error:/ or &brp_help; 	# if not error, print usage
  exit;
};

END {
  if ($server) {
    -e $brpport and unlink $brpport;
    close ($server);
  }
}

#===========================================================================
chdir $brp or				# chdir to BRP
  die "Bad BRP directory ($brp): $!\n";

# external programs
my (@curl, @zip, $win);
if ($win = $^O eq "MSWin32") {
  @curl = ("$brp/curl/bin/curl.exe");
  @zip  = ("$brp/zip/zip.exe");
  $brpport = "G:/Temp/brpport";
} else {
  @curl = ("/usr/bin/curl");
  @zip  = ("/usr/bin/zip");
  $brpport = "/tmp/brpport";
}
-x $curl[0] or die "Error: curl executable not found: $curl[0]\n";
-x $zip[0]  or die "Error: zip executable not found: $zip[0]\n";

# add command line switches
push @curl, ("--netrc-file", "netrc.txt", "--silent", "--insecure");
# encrypt with password, quiet, recursive, better compress, move (delete src)
push @zip, ( "-e", "-P", $zpass, "-q", "-r", "-9", "-m");
$ui{delete} = 1; 			# delete input data via zip -m

# special case when called from Philips inline processor - single arg is roid
# of data to be sent - modify the command line to run philips_inline command,
# process all voxels, philips swap. Start gui if not already running.
if (@ARGV && $ARGV[0] =~ $roidregex) {
  @ARGV = ("philips_inline", "philips", join (",", @voxels), "-k", $1);
  unless (-e $brpport) {
    system ("start /b $brp/brp gui");
    sleep 2;
  }
  unless (-e $brpport) { unshift @ARGV, "gui"; } # in case gui didn't start
}

# if port file exists, gui is already running. send command to the
# server so it can execute the command - do help locally
if (-e $brpport && @ARGV && $ARGV[0] ne "help") {
  $ARGV[0] eq "gui" and shift @ARGV;	# remove gui from command
  @ARGV or exit;			# gui alone is no-op
  if (my $client = IO::Socket::INET->new(PeerPort => $port,
					 PeerAddr => "localhost",
					 Proto    => 'udp',
					 Timeout  => 10)) {
    $client->send (join (" ", @ARGV)) and exit;
  }
  unlink $brpport;
  &msg ("Can't open connection to server - Executing the command.\n");
}

unless (-f "netrc.txt") {		# make netrc
  open OUT, "> netrc.txt" or die "Error: Can't create netrc.txt: $!\n";
  $brpurl =~ m|^https?://([^/]*)/.*$| or
    die "Error: Invalid url in configuration\n";
  print OUT "machine $1 login brp$site password $npass\n";
  close OUT;
}
foreach ($coord, $control) {		# create inbox and outbox
  my $dir = dirname($_);
  -d $dir or mkdir $dir, 0777 or die "Error: Can't create $dir folder: $!\n";
}
if (-f $control) {			# read or make control file
  open IN, "$control" or die "Error: Can't open $control: $!\n";
  my $txt = join "", <IN>;
  close IN;
  $txt  =~ $contregex or die "Error: Invalid $control contents\n";
  $ui{mode} = $1;
  &str2Areas ($2);
  $ui{smode} = $6 ? $7 : "siemens";
} else {				# make file with defaults
  $ui{mode} = (split /\|/, $dmodes)[0];
  &str2Areas ($voxels[0]);
  $ui{smode} = (split /\|/, $smodes)[0];
  &writeControl;
}
&brp;					# run the command

#===command routines=========================================================
# called at end of startup, in gui if added command, in repeat for client
sub brp {
  @ARGV > 0 or die "Missing command\n";	# command must be supplied
  my $cmds = join "|", keys %cmd;  	# must be one of those implemented
  $ARGV[0] =~ /^($cmds)$/ or
    die "Invalid command ($ARGV[0])\n";
  $cmd = shift @ARGV;

  # check if study name was passed in on command line
  for (my $i = 0; $i < @ARGV; $i++) {
    if ($ARGV[$i] eq "-s") {
      $i eq $#ARGV and die "-s switch requires an study name argument\n";
      $std = $ARGV[$i+1];
      push @curl, ("-F", "study=".$std);
      splice @ARGV, $i, 2;		# remove the 2 args
    }
  }

  no strict 'refs';			# turn off strict refs to allow call
  &{"brp_$cmd"}; 			# all command line commands begin brp_
}

sub brp_help {
  if ($cmd && $cmd ne "help") {		# show help for command just failed
    &msg ($cmd{$cmd});
  } elsif (@ARGV && exists $cmd{$ARGV[0]}) { # help <command>
    &msg ($cmd{$ARGV[0]});
  } else {
    &msg ($cmd{help});			# help
  }
  &msg ("
server is set to $brpurl.\n");
}

# create gui
sub brp_gui {
  use strict 'refs';
  load Tk;
  exists $ENV{HOME} or
    $ENV{HOME} = $ENV{USERPROFILE}; 	# prevent some warnings by Tk
  $ui{root} = MainWindow->new		# create gui
    (title => "BRP API") or
      die "Error: Can't create main gui window: $!\n";
  &brp_ui;				# routine from specTCL gui builder
  $ui{txMsg}->configure			# link scroll bar to message panel
    ( -yscrollcommand => ['set' => $ui{scMsg}],
      -state => "disabled");
  $ui{scMsg}->configure (-command => ['yview' => $ui{txMsg}]);
  $ui{txMsg}->tagConfigure('red', -foreground => "red"); # for errors
  $ui{root}->protocol('WM_DELETE_WINDOW' => \&exitgui);
  $std and &textReadonly ("enStudy", $std);
  # delete port id file if it exists
  -e $brpport and
    (unlink $brpport or die "Error: Can't delete port file: $!\n");
  # open port to listen for commands
  if ($server = IO::Socket::INET->new(LocalPort => $port,
				      Proto     => 'udp',
				     )) {
    open OUT, "> $brpport" or die "Error: Can't open $brpport: $!\n";
    print OUT $port, "\n";		# file to show running
    close OUT;
    $select = IO::Select->new;		# for non-blocking I/O
    $select->add($server);
    $repId = $ui{root}->repeat		# repeat to check for commands
      (2000, sub {			# every 2 sec
	 $select->can_read(0) or return;# has client sent a command
	 my $msg;
	 $server->recv ($msg, 1024);	# read it
	 @ARGV = split / /, $msg;	# split into args
	 &brp;				# run it
       });
  } else {
    &msg ("Running without server: $!\n");
  }
  $gui = 1;
  $ui{root}->update;
  if (@ARGV) {				# if initial comand provided
    $ui{root}->afterIdle (\&brp); 	# run command after GUI is up
  }
  Tk::MainLoop();			# run gui event loop
}

# make a control.ini using parameters passed in
sub brp_set_control {
  @ARGV or die "set_control requires one or more parameters\n";
  foreach (@ARGV) {
    if ($_ =~ /^($dmodes)$/) {
      $ui{mode} = $_;
    } elsif ($_ =~ /^(($voxels)(,($voxels))*)$/) {
      &str2Areas ($_);
    } elsif ($_ =~ /^($smodes)$/) {
      $ui{smode} = $_;
    } else {
      &msg ("Invalid control.ini parameter: $_\n");
    }
  }
  &writeControl;
}

# show control.ini
sub brp_show_control {
  use strict 'refs';
  open IN, "$control" or die "Error: Can't open $control: $!\n";
  my $txt = join "", <IN>;
  close IN;
  $txt =~ s/\r//g;
  &msg ("\nContents of $control\n$txt");
}

# show coordinates.ini
sub brp_show_coord {
  use strict 'refs';
  -f $coord or die "Error: There is currently no $coord file\n";
  open IN, "$coord" or die "Error: Can't open $coord: $!\n";
  my @txt = <IN>;
  close IN;
  (my $txt = join "", @txt) =~ s/\r//sg;
  &msg ("\nContents of $coord\n", $txt);
}

# show current status
sub brp_status {
  use strict 'refs';
  &msg (&getStatus, "\n");
}

# send data and control files to server
sub brp_send {
  use strict 'refs';
  my $dir;						# send needs directory
  unless ($dir = pop @ARGV) { 				# not on command line
    !$gui and die "Name of folder to send is required\n";  # not gui - error
    $dir = $ui{root}->chooseDirectory			# gui - use dir chooser
      ( -initialdir => "data",
	-title => "Choose Data Directory",
      );
    defined $dir or return 0;				# cancel
  }

  $dir =~ s|\\|/|g;					# win to unix
  -d $dir or die "Folder $dir does not exist\n";	# must be a dir

  &sender ($dir);					# send the directory
}

sub brp_send_control {
  use strict 'refs';
  # send the control.ini
  &msg (scalar localtime, " status = transmitting control file\n");
  &doCurl ("cmd=put","filename=".basename($control), "file=\@".$control,
	   "", "$site/api.php");

  # send ready command
  &msg (scalar localtime, " status = setting ready\n");
  &doCurl ("cmd=setonly", "status=ready", "", "$site/api.php");
}

sub brp_receive {
  use strict 'refs';
  # delete old coordinates, receive new one
  -f $coord and (unlink $coord or
		 die "Error: Can't delete existing $coord: $!\n");
  &msg (scalar localtime, " status = receiving\n");
  &doCurl ("cmd=get", "filename=".basename($coord),
	   "--location --output ".$coord, "$site/api.php");
  if (-s $coord == 27) { # ERROR file does not exist\r\n
    &msg (scalar localtime, " status = error\n");
    unlink $coord;
  } else {
    &msg (scalar localtime, " status = done\n");
  }
}

sub brp_send_receive {
  use strict 'refs';
  # send followed by wait for complete then receive
  &brp_send or return;
  &waitReceive;
}

sub brp_recalc_receive {
  use strict 'refs';
  unshift @ARGV, "recalc";		# force recalc
  &brp_set_control;
  &brp_send_control; 			# send control
  &waitReceive; 			# wait for complete, then receive
}

# show list of studies
sub brp_list {
  &showBrpCmd ("list");
}

# show the files in a study
sub brp_files {
  &showBrpCmd ("files");
}

# show the log for a study
sub brp_log {
  &showBrpCmd ("log");
}

# show the API help
sub brp_api_help {
  &showBrpCmd ("help");
}

# create a folder in the BRP server
sub brp_create {
  use strict 'refs';
  $std or die "create command requires a study name\n";
  &doCurl ("cmd=new", "", "$site/api.php");
}

# delete a folder in the BRP server
sub brp_delete {
  use strict 'refs';
  $std or die "delete command requires a study name\n";
  &doCurl ("cmd=delete", "", "$site/api.php");
}

sub brp_prclog {
  use strict 'refs';

  # get first date
  &doCurl ("site=$site", "", "control/log.php");
  my $dt;
  foreach (@cmdout) {
    if (m|^<li><a href='(.+)'>(\d{8})</a></li>|) { $dt = $2; last; }
  }
  $dt or die "Error: no process log dates\n";

  # get first process entry
  &doCurl ("site=$site", "date=$dt", "", "control/log.php");
  my $log;
  foreach (@cmdout) {
    if (m|^<li><a href='(.+)'>(brp\.log\.\d{8}\.\d{6})</a></li>$|) {
      $log = $2; last; }
  }
  $log or die "Error: no process log info\n";

  # get & display log file
  &doCurl ("site=$site", "date=$dt", "log=$log", "", "control/log.php");
  my $display = 0;
  foreach (@cmdout) {
    m|</pre>| and $display = 0;
    if ($display) { s/\r//g; &msg ($_); }
    /<pre>/ and $display = 1;
  }
}

# called from a Philips inline which passes the database ROID of the scan
# just completed. Code in startup converts this to "gui philips_inline
# <all-voxels> philips <ROID>". Using the ROID, retrieve the scan as XML/REC,
# convert XML to PAR, convert PAR/REC to NIFTI in new data dir, send to
# server and receive coords
sub brp_philips_inline {
  my $roid = pop @ARGV;
  chomp ($roid);
  &msg ("Series ROID: $roid\n");

  load oslnm;
  my $GYRO_ASSEMBLIES;
  oslnm::translate ("GYRO_ASSEMBLIES", $GYRO_ASSEMBLIES);
  $GYRO_ASSEMBLIES = (split /;/, $GYRO_ASSEMBLIES)[-1];
  $GYRO_ASSEMBLIES =~ s|\\|/|g;
  $GYRO_ASSEMBLIES =~ s|Program Files \(x86\)|Progra~2|;
  $GYRO_ASSEMBLIES =~ s|Program Files|Progra~1|;
  my $leacher = qq~${GYRO_ASSEMBLIES}pridexmlleacher_win_cs.exe~;
  my $dirIn   = "G:/patch/pride/tempinputseries/";
  my $dirOut  = "G:/patch/pride/tempoutputseries/";
  my $msxsl   = "$brp/Philips/msxsl.exe";
  my $xslt    = "$brp/Philips/xml2par.xslt";
  my $dcm2nii = "$brp/Philips/dcm2niix.exe";
  -x $leacher or die "$leacher binary not found\n";
  -x $msxsl   or die "$msxsl binary not found\n";
  -x $dcm2nii or die "$dcm2nii binary not found\n";
  -d $dirIn   or die "$dirIn dir not found\n";
  -d $dirOut  or die "$dirOut dir not found\n";
  -f $xslt    or die "$xslt file not found\n";

  # Cleanup the pride directories
  my @files;
  foreach ($dirIn, $dirOut) {
    @files = glob "$_/*.*";
    @files and unlink @files;
  }
  open OUT, "> $dirOut/noOutputData.ini" or
   die "Can't create noOutputData.ini: $!\n";
  print OUT "\n";
  close OUT;

  # Extracting the Xml/Rec file from the database
  &msg ("Extracting the XML/REC file from the database\n");
  my $st;
  $st = &doSystem ($leacher, $roid); # returned error code is bogus

  # check, whether 2 files are in dirIn directory
  @files = glob "$dirIn/*.{XML,REC}";
  @files == 2 or die "Error: XML/REC files not found!\n";
  &msg ("  Files: $files[0], $files[1]\n");

  # create the par file from the xml
  (my $par = $files[0]) =~ s/\.XML$/.PAR/i;
  &msg ("Converting XML to PAR\n  $msxsl $files[0] $xslt > $par\n");
  $st = &doSystem ($msxsl, $files[0], $xslt, ">", $par) and
    die "Error: Conversion failed: $st\n";

  # clear or make directory in the brp data folder
  my $data = $brp."/data/".$roid;
  if (-d $data) {
    @files = glob "$data/*";
    @files and unlink @files or die "Can't delete files in $data: $!\n";
  } else {
    mkdir $data, 0777 or die "Error: Can't mkdir $data: $!\n";
  }
  # convert to nifti
  &msg ("Converting PAR/REC to NIFTI\n  $dcm2nii -o $data $par\n");
  # -b no BIDS, -p no Philips precise, -s single file
  $st = &doSystem ($dcm2nii, "-b n -p n -s y -f DBIEX", "-o", $data, $par) and
    die "Error: dcm2nii failed: $st\n";
  -f "$data/DBIEX.nii" or die "Error: NIFTI file not found\n";

  # send to BRP, wait for complete, receieve coords
  &sender ($data);
  &waitReceive;
}

#===internal routines=========================================================

sub exitgui {
  $gui = 0;
  exit;
}

# sends a directory and control.ini to BRP
sub sender {
  my $dir = shift;

  for (my $i = 0; $i < @ARGV; $i++) {
    if ($ARGV[$i] eq "-k") {			# arg may be -k
      $ui{delete} = 0;
      &setDelete;				# keep input data
      splice @ARGV, $i, 1;			# remove arg
      last;
    }
  }

  unshift @ARGV, "upload";			# force upload
  &brp_set_control;				# set control using ARGV

  # remove old zip file, cd to data folder, zip file, chdir back
  &msg (" folder: $dir\n", scalar localtime,
	" status = compressing and encrypting\n");
  -f $zipfile and (unlink $zipfile or
		   die "Error: Can't delete existing zip file: $!\n");
  # if the dir contains only a .nii file, just zip the file. If not, assume
  # dicom and zip the folder - BRP rules.
  my ($cdir, $nii);
  my @files = glob ("$dir/*");
  if ((@files == 1) && ($files[0] =~ /\.nii$/i)) {
    $cdir = $dir;
    $dir = $files[0];
    $nii = 1;
  } else {
    $cdir = dirname($dir);
    $nii = 0;
  }
  chdir $cdir or die "Error: Can't change dir to folder $cdir\n";
  my $st = &doSystem (@zip, "$brp/$zipfile", basename($dir));
  chdir $brp;
  $st || !-f $zipfile and die "Error: zip of folder $dir failed: $st\n".
    join (" ", @zip, "$brp/$zipfile", basename($dir))."\n".@cmdout;
  $nii && $ui{delete} and rmdir $cdir;

  # send the zip file
  &msg (scalar localtime, " status = transmitting\n");
  &doCurl ("cmd=put", "filename=".basename($zipfile), "file=\@".$zipfile,
	   "", "$site/api.php");

  # send the control & ready
  &brp_send_control;
  return 1;
}

# callback for delete checkbox
sub setDelete {
  if ($ui{delete}) {
    push @zip, "-m";
  } else {
    pop @zip;
  }
}

# convert string of voxel names to areas variables
sub str2Areas {
  for (my $i = 0; $i < @voxels; $i++) {
    $ui{"areas$i"} = grep (/$voxels[$i]/, $_[0]) ? 1 : 0;
  }
}

# convert areas variables to string of voxels names
sub areas2Str {
  my @areas;
  for (my $i = 0; $i < @voxels; $i++) {
    $ui{"areas$i"} and push @areas, $voxels[$i];
  }
  return join ",", @areas;
}

# show the output of a simple BRP server command
sub showBrpCmd {
  use strict 'refs';
  &doCurl ("cmd=$_[0]", "", "$site/api.php");
  &msg ("\nOutput of the $_[0] command\n", @cmdout);
}

# return status from BRP server and display in GUI
sub getStatus {
  &doCurl ("cmd=status", "", "$site/api.php");
  @cmdout == 2 or			# successful if 2 lines returned
    die "Error getting status\n@cmdout";
  chomp $cmdout[1];			# 2nd line is status
  $gui and &textReadonly ("enStatus", $cmdout[1]);
  return $cmdout[1];
}

# write mode and areas to control file - called whenever mode or areas change
sub writeControl {
  open OUT, "> $control" or die "Error: Can't create $control: $!\n";
  print OUT "dataMode=$ui{mode}\nvoxelArea=".&areas2Str."\n",
    $ui{smode} && $ui{smode} ne "siemens" ? "swapMode=$ui{smode}\n" : "";
  close OUT;
}

# wait for complete and receive coordinates file
sub waitReceive {
  my $n;
  for ($n = 0; $n < $retries; $n++) {		# don't wait forever
    my $st = &getStatus;
    &msg (scalar localtime, " status = $st\n");
    $st eq "failed" and die "Error: Processing failed\n";
    $st eq "complete" and last;
    sleep $sleep;
  }
  $n == $retries and die "Error: Too many retries - Giving up\n";
  &brp_receive;
}

#===service routines=========================================================
# CURL command - assumes all args are html form content except last
sub doCurl {
  my $url = $brpurl.pop;
  my $params = pop;
  my $st = &doSystem (@curl, map ({"-F $_"} @_), $params, $url) or
    return;				# st = 0 is success
  $st =~ /exit status (\d+)/s;		# get error number
  die "Error: CURL transaction failed: $st\n",
    &curlerr($1), "\n@cmdout";
}

# execute a system command in a pipe with stdout and err going to cmdout array
# return 0 on success, text with error on failure
sub doSystem {
  @cmdout = ();
  my $rc;
  my $pipe = join " ", @_, "2>&1", "|";
  #print "\n", $pipe,"\n";
  if (open PIPE, $pipe) {
    while (<PIPE>) {
      s/\r//g;
      push @cmdout, $_;
    }
    close PIPE;
    $rc = $? or return 0;		   # success
  } else { $rc = $!; }			   # error opening pipe
  return "$_[0] failed: " .
    ($rc == 0xff00 ? "command error: $!" : # pipe failed
     ($rc & 0xff) == 0 ? "exit status " . ( $rc >> 8 ) : # non-zero status
     ( $rc & 0x80 ? "coredump, " : "" ) .  # dumped and...
     "signal " . ( $rc & ~0x80 )	   # died on signal
    );
}

# called after die in GUI mode
sub Tk::Error {
  my ($widget, $error, @locations) = @_;
  &msg ($error)
}

# print message or if gui, insert into message area
sub msg {
  my $txt = join "", @_;
  unless ($gui) { print $txt; return; }
  my $tag = "";
  $txt =~ /error|failed/i and $tag = "red";
  $ui{txMsg}->configure(-state => "normal");
  $ui{txMsg}->insert("end", $txt, $tag);
  $ui{txMsg}->update;
  $ui{txMsg}->see("end");
  $ui{txMsg}->configure(-state => "disabled");
}

# callback for clear messages button
sub clearMsg {
  $ui{txMsg}->configure(-state => "normal");
  $ui{txMsg}->delete("0.0",'end');
  $ui{txMsg}->update;
  $ui{txMsg}->see("end");
  $ui{txMsg}->configure(-state => "disabled");
}

# insert text into readonly entry
sub textReadonly {
  $ui{$_[0]}->configure(-state => "normal");
  $ui{$_[0]}->delete(0,"end");
  $ui{$_[0]}->insert('end', $_[1]);
  $ui{$_[0]}->configure(-state => "readonly");
}

# callback for Help GUI button
sub Help {
  $help = 1 - $help;		# turn on or off
  $ui{buHelp}->configure(-foreground => $help ? "Red" : "Black");
  foreach my $k (keys %help) {
    $ui{$k}->bind ('<Enter>', $help ? [\&helpUp, $k] : "");
    $ui{$k}->bind ('<Leave>', "");
  }
}

# callback when cursor enters control that shows help
sub helpUp {
  my $wg = pop;					# button name
  unless ($dlgHlp) {				# 1st time create help dialog
    $dlgHlp = $ui{root}->Toplevel(-title => "Help",);
    $dlgHlp->overrideredirect(1);
    my $dlgFr = $dlgHlp->Frame
      (
       -borderwidth => '1',
       -padx => '10',
       -pady => '10',
       -relief => 'groove',
      ) -> pack (-fill => "both");
    my $lbl = $dlgFr->Label
      (
       -justify => "left",
       -textvariable => \$ui{helpMsg}
      ) -> pack (-fill => "both");
  } else {
    $dlgHlp->deiconify();			# help dialog visible
    $dlgHlp->raise();
    $dlgHlp->update();
  }
  $ui{helpMsg} = $help{$wg};			# insert help text into label
  # geo of main window
  my ($wx, $wy) = (split /[x|+]/, $ui{root}->geometry)[2,3];
  # geo of control
  my ($w, $h, $x, $y) = split /[x|+]/, $ui{$wg}->geometry;
  $x = $wx + $x + $w + 10;
  $y = $wy + $y + $h + 10;
  $dlgHlp->geometry ("+$x+$y");			# position help dialog
  $ui{$wg}->bind ('<Enter>', "");		# remove enter callback
  $ui{$wg}->bind ('<Leave>', [\&helpDown, $wg]);  # add leave callback
}

# callback when cursor leaves control that showing help
sub helpDown {
  my $wg = pop;					# button name
  $dlgHlp->withdraw();				# help dialog invisible
  $ui{$wg}->bind ('<Leave>', ""); 		# remove leave callback
  $ui{$wg}->bind ('<Enter>', [\&helpUp, $wg]);  # add enter callback
}

sub curlerr {
  # all possible curl errors - array index is error number
  my @curlerr =
    ("", "Unsupported protocol.", "Failed to initialize.", "URL malformed.",
     "A feature or option not enabled.", "Couldn't resolve proxy.",
     "Couldn't resolve host.", "Failed to connect to host.",
     "Unknown FTP server response.", "FTP access denied.","FTP accept failed.",
     "FTP weird PASS reply.", "PORT timeout expired.",
     "Unknown response to FTP PASV.", "Unknown FTP 227 format.",
     "FTP can't get host.", "HTTP/2 error.", "FTP couldn't set binary.",
     "Partial file.", "FTP couldn't download/access the given file.",
     "Not used", "Quote error.", "HTTP page not retrieved.", "Write error.",
     "Not used", "Upload failed.", "Read error.", "Out of memory.",
     "Operation timeout.", "Not used", "FTP PORT failed.",
     "FTP couldn't use REST.", "Not used", "HTTP range error.",
     "HTTP post error.", "A TLS/SSL connect error.", "Bad download resume.",
     "Couldn't read the given file when using the FILE:// scheme.",
     "LDAP cannot bind.", "LDAP search failed.", "Not used", "Not used",
     "Aborted by callback.", "Bad function argument.", "Not used",
     "Interface error.", "Not used", "Too many redirects.",
     "Unknown option specified to libcurl.", "Malformed telnet option.",
     "Not used", "SSL/TLS certificate or SSH fingerprint failed verification.",
     "The server didn't reply anything.", "SSL crypto engine not found.",
     "Cannot set SSL crypto engine as default.",
     "Failed sending network data.",
     "Failure in receiving network data.", "Not used",
     "Problem with the local certificate.",
     "Couldn't use specified SSL cipher.",
     "Peer certificate cannot be authenticated with known CA certificates.",
     "Unrecognized transfer encoding.", "Invalid LDAP URL.",
     "Maximum file size exceeded.", "Requested FTP SSL level failed.",
     "Sending the data requires a rewind that failed.",
     "Failed to initialize SSL Engine.", "User name, password not accepted.",
     "File not found on TFTP server.", "Permission problem on TFTP server.",
     "Out of disk space on TFTP server.", "Illegal TFTP operation.",
     "Unknown TFTP transfer ID.", "File already exists (TFTP).",
     "No such user (TFTP).", "Character conversion failed.",
     "Character conversion functions required.",
     "Problem with reading the SSL CA cert",
     "The resource referenced in the URL does not exist.",
     "An unspecified error occurred during the SSH session.",
     "Failed to shut down the SSL connection.", "Not used",
     "Could not load CRL file, missing or wrong format",
     "TLS certificate issuer check failed", "The FTP PRET command failed",
     "RTSP: mismatch of CSeq numbers", "RTSP: mismatch of Session Identifiers",
     "unable to parse FTP file list", "FTP chunk callback reported error",
     "No connection available, the session will be queued",
     "SSL public key does not matched pinned public key");
  return $curlerr[$_[0]];
}

#===GUI=========================================================
# interface generated by SpecTcl (Perl enabled) version 1.2 
# from /Users/jgillen1/Documents/Ppe/brpdev/brp.ui
# For use with Tk400.202, using the gridbag geometry manager

sub brp_ui {

	# widget creation 

	$ui{frMsg} = $ui{root}->Frame (
		-borderwidth => '1',
		-padx => '10',
		-pady => '10',
		-relief => 'groove',
	);
	$ui{frControl} = $ui{root}->Frame (
		-borderwidth => '1',
		-padx => '10',
		-pady => '10',
		-relief => 'groove',
	);
	$ui{frTop} = $ui{root}->Frame (
	);
	$ui{frStatusComands} = $ui{root}->Frame (
		-borderwidth => '1',
		-padx => '10',
		-pady => '10',
		-relief => 'groove',
	);
	$ui{frSendCommands} = $ui{root}->Frame (
		-borderwidth => '1',
		-padx => '10',
		-pady => '10',
		-relief => 'groove',
	);
	$ui{frMode} = $ui{root}->Frame (
	);
	$ui{frVoxels} = $ui{root}->Frame (
	);
	$ui{frSMode} = $ui{root}->Frame (
	);
	$ui{lbTitle} = $ui{root}->Label (
		-text => ' BRP File Transfer',
	);
	$ui{lbStudy} = $ui{root}->Label (
		-text => 'Study:',
	);
	$ui{enStudy} = $ui{root}->Entry (
		-state => 'disabled',
		-width => '10',
	);
	$ui{buHelp} = $ui{root}->Button (
		-text => 'Help',
	);
	$ui{lbSendCommands} = $ui{root}->Label (
		-justify => 'left',
		-text => 'Send Commands',
	);
	$ui{lbStatusCommands} = $ui{root}->Label (
		-text => 'Status Commands',
	);
	$ui{buStatus} = $ui{root}->Button (
		-justify => 'left',
		-text => 'Status',
	);
	$ui{enStatus} = $ui{root}->Entry (
		-state => 'disabled',
		-width => '10',
	);
	$ui{buSend} = $ui{root}->Button (
		-text => 'Send',
	);
	$ui{buSendRec} = $ui{root}->Button (
		-text => 'Send Receive',
	);
	$ui{buFiles} = $ui{root}->Button (
		-justify => 'left',
		-text => 'Files',
	);
	$ui{buShowCoord} = $ui{root}->Button (
		-text => 'Show Coords',
	);
	$ui{cbDelete} = $ui{root}->Checkbutton (
		-text => 'Delete after send',
		-variable => \$ui{delete},
	);
	$ui{buLog} = $ui{root}->Button (
		-justify => 'left',
		-text => 'Log',
	);
	$ui{buPrcLog} = $ui{root}->Button (
		-text => 'Process Log',
	);
	$ui{buReceive} = $ui{root}->Button (
		-text => 'Receive',
	);
	$ui{buRecalcReceive} = $ui{root}->Button (
		-text => 'Recalc Receive',
	);
	$ui{lbControlFile} = $ui{root}->Label (
		-justify => 'left',
		-text => 'Control File',
	);
	$ui{buSaveControl} = $ui{root}->Button (
		-text => 'Save',
	);
	$ui{buShowControl} = $ui{root}->Button (
		-text => 'Show',
	);
	$ui{buSendControl} = $ui{root}->Button (
		-text => 'Send',
	);
	$ui{lbMode} = $ui{root}->Label (
		-justify => 'left',
		-text => ' Mode:',
	);
	$ui{rbMode1} = $ui{root}->Radiobutton (
		-text => 'upload',
		-value => 'upload',
		-variable => \$ui{mode},
	);
	$ui{rbMode2} = $ui{root}->Radiobutton (
		-text => 'recalc',
		-value => 'recalc',
		-variable => \$ui{mode},
	);
	$ui{lbSMode} = $ui{root}->Label (
		-text => 'Swap Mode',
	);
	$ui{rbSMode0} = $ui{root}->Radiobutton (
		-text => 'Siemens',
		-value => 'siemens',
		-variable => \$ui{smode},
	);
	$ui{rbSMode1} = $ui{root}->Radiobutton (
		-text => 'Philips',
		-value => 'philips',
		-variable => \$ui{smode},
	);
	$ui{lbVoxels} = $ui{root}->Label (
		-justify => 'left',
		-text => 'Voxels:',
	);
	$ui{cbVoxel0} = $ui{root}->Checkbutton (
		-text => 'cbwm',
		-variable => \$ui{areas0},
	);
	$ui{cbVoxel1} = $ui{root}->Checkbutton (
		-text => 'hippo',
		-variable => \$ui{areas1},
	);
	$ui{cbVoxel2} = $ui{root}->Checkbutton (
		-text => 'pcc',
		-variable => \$ui{areas2},
	);
	$ui{cbVoxel3} = $ui{root}->Checkbutton (
		-text => 'pons',
		-variable => \$ui{areas3},
	);
	$ui{cbVoxel4} = $ui{root}->Checkbutton (
		-text => 'vermis',
		-variable => \$ui{areas4},
	);
	$ui{cbVoxel5} = $ui{root}->Checkbutton (
		-text => 'putamen',
		-variable => \$ui{areas5},
	);
	$ui{cbVoxel6} = $ui{root}->Checkbutton (
		-text => 'occ',
		-variable => \$ui{areas6},
	);
	$ui{lbMessages} = $ui{root}->Label (
		-justify => 'left',
		-text => 'Messages',
	);
	$ui{buClearMessages} = $ui{root}->Button (
		-text => 'Clear Messages',
	);
	$ui{txMsg} = $ui{root}->Text (
		-height => '1',
		-width => '1',
	);
	$ui{scMsg} = $ui{root}->Scrollbar (
	);

	# widget commands

	$ui{buHelp}->configure(
		-command => \&Help
	);
	$ui{buStatus}->configure(
		-command => \&brp_status
	);
	$ui{buSend}->configure(
		-command => \&brp_send
	);
	$ui{buSendRec}->configure(
		-command => \&brp_send_receive
	);
	$ui{buFiles}->configure(
		-command => \&brp_files
	);
	$ui{buShowCoord}->configure(
		-command => \&brp_show_coord
	);
	$ui{cbDelete}->configure(
		-command => \&setDelete
	);
	$ui{buLog}->configure(
		-command => \&brp_log
	);
	$ui{buPrcLog}->configure(
		-command => \&brp_prclog
	);
	$ui{buReceive}->configure(
		-command => \&brp_receive
	);
	$ui{buRecalcReceive}->configure(
		-command => \&brp_recalc_receive
	);
	$ui{buSaveControl}->configure(
		-command => \&writeControl
	);
	$ui{buShowControl}->configure(
		-command => \&brp_show_control
	);
	$ui{buSendControl}->configure(
		-command => \&brp_send_control
	);
	$ui{rbMode1}->configure(
		-command => \&writeControl
	);
	$ui{rbMode2}->configure(
		-command => \&writeControl
	);
	$ui{rbSMode0}->configure(
		-command => \&writeControl
	);
	$ui{rbSMode1}->configure(
		-command => \&writeControl
	);
	$ui{cbVoxel0}->configure(
		-command => \&writeControl
	);
	$ui{cbVoxel1}->configure(
		-command => \&writeControl
	);
	$ui{cbVoxel2}->configure(
		-command => \&writeControl
	);
	$ui{cbVoxel3}->configure(
		-command => \&writeControl
	);
	$ui{cbVoxel4}->configure(
		-command => \&writeControl
	);
	$ui{cbVoxel5}->configure(
		-command => \&writeControl
	);
	$ui{cbVoxel6}->configure(
		-command => \&writeControl
	);
	$ui{buClearMessages}->configure(
		-command => \&clearMsg
	);

	# Geometry management

	$ui{frMsg}->grid(
		-in => $ui{root},
		-column => '1',
		-row => '4',
		-columnspan => '2',
		-sticky => 'nesw'
	);
	$ui{frControl}->grid(
		-in => $ui{root},
		-column => '1',
		-row => '3',
		-columnspan => '2',
		-sticky => 'nesw'
	);
	$ui{frTop}->grid(
		-in => $ui{root},
		-column => '1',
		-row => '1',
		-columnspan => '2',
		-sticky => 'nesw'
	);
	$ui{frStatusComands}->grid(
		-in => $ui{root},
		-column => '2',
		-row => '2',
		-sticky => 'nesw'
	);
	$ui{frSendCommands}->grid(
		-in => $ui{root},
		-column => '1',
		-row => '2',
		-sticky => 'nesw'
	);
	$ui{frMode}->grid(
		-in => $ui{frControl},
		-column => '1',
		-row => '2',
		-columnspan => '2',
		-sticky => 'nesw'
	);
	$ui{frVoxels}->grid(
		-in => $ui{frControl},
		-column => '1',
		-row => '3',
		-columnspan => '4',
		-sticky => 'nesw'
	);
	$ui{frSMode}->grid(
		-in => $ui{frControl},
		-column => '3',
		-row => '2',
		-columnspan => '2',
		-sticky => 'nesw'
	);
	$ui{lbTitle}->grid(
		-in => $ui{frTop},
		-column => '1',
		-row => '1'
	);
	$ui{lbStudy}->grid(
		-in => $ui{frTop},
		-column => '2',
		-row => '1'
	);
	$ui{enStudy}->grid(
		-in => $ui{frTop},
		-column => '3',
		-row => '1',
		-padx => '5'
	);
	$ui{buHelp}->grid(
		-in => $ui{frTop},
		-column => '4',
		-row => '1',
		-padx => '5'
	);
	$ui{lbSendCommands}->grid(
		-in => $ui{frSendCommands},
		-column => '1',
		-row => '1',
		-columnspan => '2',
		-sticky => 'w'
	);
	$ui{lbStatusCommands}->grid(
		-in => $ui{frStatusComands},
		-column => '1',
		-row => '1',
		-columnspan => '2',
		-sticky => 'w'
	);
	$ui{buStatus}->grid(
		-in => $ui{frStatusComands},
		-column => '1',
		-row => '2',
		-padx => '5'
	);
	$ui{enStatus}->grid(
		-in => $ui{frStatusComands},
		-column => '2',
		-row => '2',
		-padx => '5'
	);
	$ui{buSend}->grid(
		-in => $ui{frSendCommands},
		-column => '1',
		-row => '2',
		-padx => '5',
		-sticky => 'ew'
	);
	$ui{buSendRec}->grid(
		-in => $ui{frSendCommands},
		-column => '2',
		-row => '2',
		-padx => '5',
		-sticky => 'ew'
	);
	$ui{buFiles}->grid(
		-in => $ui{frStatusComands},
		-column => '1',
		-row => '3',
		-padx => '5',
		-sticky => 'ew'
	);
	$ui{buShowCoord}->grid(
		-in => $ui{frStatusComands},
		-column => '2',
		-row => '3',
		-padx => '5'
	);
	$ui{cbDelete}->grid(
		-in => $ui{frSendCommands},
		-column => '2',
		-row => '3'
	);
	$ui{buLog}->grid(
		-in => $ui{frStatusComands},
		-column => '1',
		-row => '4',
		-padx => '5',
		-sticky => 'ew'
	);
	$ui{buPrcLog}->grid(
		-in => $ui{frStatusComands},
		-column => '2',
		-row => '4'
	);
	$ui{buReceive}->grid(
		-in => $ui{frSendCommands},
		-column => '1',
		-row => '4',
		-padx => '5'
	);
	$ui{buRecalcReceive}->grid(
		-in => $ui{frSendCommands},
		-column => '2',
		-row => '4',
		-padx => '5'
	);
	$ui{lbControlFile}->grid(
		-in => $ui{frControl},
		-column => '1',
		-row => '1',
		-sticky => 'w'
	);
	$ui{buSaveControl}->grid(
		-in => $ui{frControl},
		-column => '2',
		-row => '1',
		-padx => '10',
		-sticky => 'nesw'
	);
	$ui{buShowControl}->grid(
		-in => $ui{frControl},
		-column => '3',
		-row => '1',
		-padx => '10',
		-sticky => 'nesw'
	);
	$ui{buSendControl}->grid(
		-in => $ui{frControl},
		-column => '4',
		-row => '1',
		-padx => '10',
		-sticky => 'nsw'
	);
	$ui{lbMode}->grid(
		-in => $ui{frMode},
		-column => '1',
		-row => '1',
		-sticky => 'w'
	);
	$ui{rbMode1}->grid(
		-in => $ui{frMode},
		-column => '2',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{rbMode2}->grid(
		-in => $ui{frMode},
		-column => '3',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{lbSMode}->grid(
		-in => $ui{frSMode},
		-column => '1',
		-row => '1',
		-sticky => 'nesw'
	);
	$ui{rbSMode0}->grid(
		-in => $ui{frSMode},
		-column => '2',
		-row => '1',
		-sticky => 'nesw'
	);
	$ui{rbSMode1}->grid(
		-in => $ui{frSMode},
		-column => '3',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{lbVoxels}->grid(
		-in => $ui{frVoxels},
		-column => '1',
		-row => '1',
		-sticky => 'w'
	);
	$ui{cbVoxel0}->grid(
		-in => $ui{frVoxels},
		-column => '2',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{cbVoxel1}->grid(
		-in => $ui{frVoxels},
		-column => '3',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{cbVoxel2}->grid(
		-in => $ui{frVoxels},
		-column => '4',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{cbVoxel3}->grid(
		-in => $ui{frVoxels},
		-column => '5',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{cbVoxel4}->grid(
		-in => $ui{frVoxels},
		-column => '6',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{cbVoxel5}->grid(
		-in => $ui{frVoxels},
		-column => '7',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{cbVoxel6}->grid(
		-in => $ui{frVoxels},
		-column => '8',
		-row => '1',
		-sticky => 'nsw'
	);
	$ui{lbMessages}->grid(
		-in => $ui{frMsg},
		-column => '1',
		-row => '1',
		-sticky => 'w'
	);
	$ui{buClearMessages}->grid(
		-in => $ui{frMsg},
		-column => '2',
		-row => '1'
	);
	$ui{txMsg}->grid(
		-in => $ui{frMsg},
		-column => '1',
		-row => '2',
		-columnspan => '2',
		-sticky => 'nesw'
	);
	$ui{scMsg}->grid(
		-in => $ui{frMsg},
		-column => '3',
		-row => '2',
		-sticky => 'nesw'
	);

	# Resize behavior management

	# container $ui{frTop} (rows)
	$ui{frTop}->gridRowconfigure(1, -weight  => 0, -minsize  => 30);

	# container $ui{frTop} (columns)
	$ui{frTop}->gridColumnconfigure(1, -weight => 1, -minsize => 162);
	$ui{frTop}->gridColumnconfigure(2, -weight => 0, -minsize => 30);
	$ui{frTop}->gridColumnconfigure(3, -weight => 0, -minsize => 30);
	$ui{frTop}->gridColumnconfigure(4, -weight => 0, -minsize => 30);

	# container $ui{frVoxels} (rows)
	$ui{frVoxels}->gridRowconfigure(1, -weight  => 0, -minsize  => 30);

	# container $ui{frVoxels} (columns)
	$ui{frVoxels}->gridColumnconfigure(1, -weight => 0, -minsize => 30);
	$ui{frVoxels}->gridColumnconfigure(2, -weight => 0, -minsize => 30);
	$ui{frVoxels}->gridColumnconfigure(3, -weight => 0, -minsize => 30);
	$ui{frVoxels}->gridColumnconfigure(4, -weight => 0, -minsize => 30);
	$ui{frVoxels}->gridColumnconfigure(5, -weight => 0, -minsize => 30);
	$ui{frVoxels}->gridColumnconfigure(6, -weight => 1, -minsize => 30);
	$ui{frVoxels}->gridColumnconfigure(7, -weight => 0, -minsize => 30);
	$ui{frVoxels}->gridColumnconfigure(8, -weight => 0, -minsize => 30);

	# container $ui{frStatusComands} (rows)
	$ui{frStatusComands}->gridRowconfigure(1, -weight  => 0, -minsize  => 2);
	$ui{frStatusComands}->gridRowconfigure(2, -weight  => 0, -minsize  => 30);
	$ui{frStatusComands}->gridRowconfigure(3, -weight  => 0, -minsize  => 30);
	$ui{frStatusComands}->gridRowconfigure(4, -weight  => 0, -minsize  => 30);

	# container $ui{frStatusComands} (columns)
	$ui{frStatusComands}->gridColumnconfigure(1, -weight => 0, -minsize => 30);
	$ui{frStatusComands}->gridColumnconfigure(2, -weight => 0, -minsize => 2);

	# container $ui{frSMode} (rows)
	$ui{frSMode}->gridRowconfigure(1, -weight  => 0, -minsize  => 15);

	# container $ui{frSMode} (columns)
	$ui{frSMode}->gridColumnconfigure(1, -weight => 0, -minsize => 2);
	$ui{frSMode}->gridColumnconfigure(2, -weight => 1, -minsize => 30);
	$ui{frSMode}->gridColumnconfigure(3, -weight => 0, -minsize => 30);

	# container $ui{root} (rows)
	$ui{root}->gridRowconfigure(1, -weight  => 0, -minsize  => 30);
	$ui{root}->gridRowconfigure(2, -weight  => 0, -minsize  => 118);
	$ui{root}->gridRowconfigure(3, -weight  => 0, -minsize  => 30);
	$ui{root}->gridRowconfigure(4, -weight  => 1, -minsize  => 253);

	# container $ui{root} (columns)
	$ui{root}->gridColumnconfigure(1, -weight => 1, -minsize => 122);
	$ui{root}->gridColumnconfigure(2, -weight => 1, -minsize => 2);

	# container $ui{frControl} (rows)
	$ui{frControl}->gridRowconfigure(1, -weight  => 0, -minsize  => 2);
	$ui{frControl}->gridRowconfigure(2, -weight  => 0, -minsize  => 30);
	$ui{frControl}->gridRowconfigure(3, -weight  => 0, -minsize  => 30);

	# container $ui{frControl} (columns)
	$ui{frControl}->gridColumnconfigure(1, -weight => 0, -minsize => 12);
	$ui{frControl}->gridColumnconfigure(2, -weight => 0, -minsize => 60);
	$ui{frControl}->gridColumnconfigure(3, -weight => 0, -minsize => 30);
	$ui{frControl}->gridColumnconfigure(4, -weight => 1, -minsize => 30);

	# container $ui{frMsg} (rows)
	$ui{frMsg}->gridRowconfigure(1, -weight  => 0, -minsize  => 30);
	$ui{frMsg}->gridRowconfigure(2, -weight  => 1, -minsize  => 30);

	# container $ui{frMsg} (columns)
	$ui{frMsg}->gridColumnconfigure(1, -weight => 1, -minsize => 30);
	$ui{frMsg}->gridColumnconfigure(2, -weight => 0, -minsize => 30);
	$ui{frMsg}->gridColumnconfigure(3, -weight => 0, -minsize => 15);

	# container $ui{frMode} (rows)
	$ui{frMode}->gridRowconfigure(1, -weight  => 0, -minsize  => 5);

	# container $ui{frMode} (columns)
	$ui{frMode}->gridColumnconfigure(1, -weight => 0, -minsize => 12);
	$ui{frMode}->gridColumnconfigure(2, -weight => 0, -minsize => 30);
	$ui{frMode}->gridColumnconfigure(3, -weight => 0, -minsize => 30);
	$ui{frMode}->gridColumnconfigure(4, -weight => 1, -minsize => 30);

	# container $ui{frSendCommands} (rows)
	$ui{frSendCommands}->gridRowconfigure(1, -weight  => 0, -minsize  => 30);
	$ui{frSendCommands}->gridRowconfigure(2, -weight  => 0, -minsize  => 30);
	$ui{frSendCommands}->gridRowconfigure(3, -weight  => 0, -minsize  => 30);
	$ui{frSendCommands}->gridRowconfigure(4, -weight  => 0, -minsize  => 30);

	# container $ui{frSendCommands} (columns)
	$ui{frSendCommands}->gridColumnconfigure(1, -weight => 0, -minsize => 30);
	$ui{frSendCommands}->gridColumnconfigure(2, -weight => 0, -minsize => 30);

	# additional interface code
	# end additional interface code

}
